import Foundation

struct Product: Identifiable, Codable {
    var id: Int?
    var name: String
    var price: Double
    var currency: String
    var description: String
    var image: String
    
    // Decoded image (excluded from serialization)
    var decodedImage: Data? {
        let base64String = image.replacingOccurrences(of: "data:image/jpeg;base64,", with: "")
        return Data(base64Encoded: base64String)
    }
    
    enum CodingKeys: String, CodingKey {
        case id, name, price, currency, description, image
    }
}
