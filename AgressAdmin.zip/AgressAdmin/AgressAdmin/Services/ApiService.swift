import Foundation

class ApiService: ObservableObject {
    @Published var products: [Product] = []
    @Published var logMessages: [String] = []
    private let settings: Settings

    init(settings: Settings) {
        self.settings = settings
    }

    var baseURL: String {
        settings.apiDomain
    }

    func fetchProducts() {
        guard let url = URL(string: "\(baseURL)/products") else { return }
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                let message = "Error fetching products: \(error.localizedDescription)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    self.logMessages.append("Invalid response from server.")
                }
                return
            }

            let statusCode = httpResponse.statusCode

            if (200...299).contains(statusCode) {
                guard let data = data else {
                    DispatchQueue.main.async {
                        self.logMessages.append("No data received.")
                    }
                    return
                }
                do {
                    let products = try JSONDecoder().decode([Product].self, from: data)
                    DispatchQueue.main.async {
                        self.products = products
                        self.logMessages.append("Products fetched successfully. Status code: \(statusCode)")
                    }
                } catch {
                    let message = "Error decoding JSON: \(error.localizedDescription)"
                    print(message)
                    DispatchQueue.main.async {
                        self.logMessages.append(message)
                    }
                }
            } else {
                let message = "Error fetching products: Server returned status code \(statusCode)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                }
            }
        }
        task.resume()
    }

    func deleteProduct(id: Int) {
        guard let url = URL(string: "\(baseURL)/product/\(id)") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        addAuthHeader(to: &request)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                let message = "Error deleting product: \(error.localizedDescription)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    self.logMessages.append("Invalid response from server.")
                }
                return
            }

            let statusCode = httpResponse.statusCode

            if (200...299).contains(statusCode) {
                DispatchQueue.main.async {
                    self.products.removeAll { $0.id == id }
                    self.logMessages.append("Product deleted successfully. Status code: \(statusCode)")
                }
            } else {
                let message = "Error deleting product: Server returned status code \(statusCode)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                }
            }
        }
        task.resume()
    }

    func addProduct(_ product: Product, completion: @escaping (_ success: Bool, _ errorMessage: String?) -> Void) {
        guard let url = URL(string: "\(baseURL)/product") else {
            completion(false, "Invalid URL.")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        addAuthHeader(to: &request)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(product)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                let message = "Error adding product: \(error.localizedDescription)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                    completion(false, message)
                }
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else {
                let message = "Invalid response from server."
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                    completion(false, message)
                }
                return
            }
            let statusCode = httpResponse.statusCode
            if (200...299).contains(statusCode) {
                DispatchQueue.main.async {
                    self.logMessages.append("Product added successfully. Status code: \(statusCode)")
                    completion(true, nil)
                }
            } else {
                let message = "Error adding product: Server returned status code \(statusCode)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                    completion(false, message)
                }
            }
        }
        task.resume()
    }


    func updateProduct(_ product: Product, completion: @escaping (_ success: Bool, _ errorMessage: String?) -> Void) {
        guard let id = product.id, let url = URL(string: "\(baseURL)/product/\(id)") else {
            completion(false, "Invalid product ID or URL.")
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        addAuthHeader(to: &request)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(product)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                let message = "Error updating product: \(error.localizedDescription)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                    completion(false, message)
                }
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else {
                let message = "Invalid response from server."
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                    completion(false, message)
                }
                return
            }
            let statusCode = httpResponse.statusCode
            if (200...299).contains(statusCode) {
                DispatchQueue.main.async {
                    self.logMessages.append("Product updated successfully. Status code: \(statusCode)")
                    completion(true, nil)
                }
            } else {
                let message = "Error updating product: Server returned status code \(statusCode)"
                print(message)
                DispatchQueue.main.async {
                    self.logMessages.append(message)
                    completion(false, message)
                }
            }
        }
        task.resume()
    }


    private func addAuthHeader(to request: inout URLRequest) {
        if !settings.adminApiKey.isEmpty {
            request.setValue("Bearer \(settings.adminApiKey)", forHTTPHeaderField: "Authorization")
        }
    }
}
