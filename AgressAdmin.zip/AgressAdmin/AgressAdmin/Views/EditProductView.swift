import SwiftUI

struct EditProductView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var apiService: ApiService
    @State var product: Product

    var isEditing: Bool

    @State private var errorMessage: String?
    @State private var showImagePicker = false
    @State private var selectedImageData: Data?
    @State private var imageMimeType: String? // Holds the MIME type of the image

    // Configured NumberFormatter
    private static let decimalFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 2 // Adjust as needed
        formatter.minimumFractionDigits = 0
        formatter.locale = Locale.current
        return formatter
    }()

    var body: some View {
        Form {
            TextField("Product Name", text: $product.name)
            TextField("Price", value: $product.price, formatter: Self.decimalFormatter)
                .keyboardType(.decimalPad)
            TextField("Currency", text: $product.currency)
            TextField("Description", text: $product.description)

            // Display Selected Image
            if let selectedImageData,
               let uiImage = UIImage(data: selectedImageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
            }

            Button(action: {
                showImagePicker = true
            }) {
                Text("Select Image")
            }
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(imageData: $selectedImageData, mimeType: $imageMimeType)
                    .onDisappear {
                        if let data = selectedImageData, let mimeType = imageMimeType {
                            // Encode image as base64 and prepend the required prefix
                            let base64String = data.base64EncodedString()
                            self.product.image = "data:\(mimeType);base64,\(base64String)"
                        }
                    }
            }

            if let error = errorMessage {
                Text(error)
                    .foregroundColor(.red)
            }

            Button(action: saveProduct) {
                Text(isEditing ? "Save Changes" : "Add Product")
            }
        }
        .navigationTitle(isEditing ? "Edit Product" : "Add Product")
        .onAppear {
            // If editing, load the existing image data
            if isEditing,
               let dataRange = product.image.range(of: ";base64,") {
                // Extract the MIME type and base64 data
                let mimeTypeRange = product.image.range(of: "data:")!.upperBound..<dataRange.lowerBound
                let mimeType = String(product.image[mimeTypeRange])
                let base64Data = String(product.image[dataRange.upperBound...])
                if let data = Data(base64Encoded: base64Data) {
                    selectedImageData = data
                    imageMimeType = mimeType
                }
            }
        }
    }

    func saveProduct() {
        if isEditing {
            apiService.updateProduct(product) { success, error in
                if success {
                    presentationMode.wrappedValue.dismiss()
                } else if let error = error {
                    errorMessage = error
                }
            }
        } else {
            apiService.addProduct(product) { success, error in
                if success {
                    apiService.fetchProducts()
                    presentationMode.wrappedValue.dismiss()
                } else if let error = error {
                    errorMessage = error
                }
            }
        }
    }
}

// ImagePicker for selecting and editing images
import MobileCoreServices // Needed for UTType

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var imageData: Data?
    @Binding var mimeType: String? // To store the MIME type

    func makeUIViewController(context: Context) -> some UIViewController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true // Enable editing and cropping
        return picker
    }

    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        // No updates needed
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        // UIImagePickerController Delegate Methods
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            picker.dismiss(animated: true)

            var imageData: Data?
            var mimeType: String?

            if let editedImage = info[.editedImage] as? UIImage {
                // Try PNG first
                if let data = editedImage.pngData() {
                    imageData = data
                    mimeType = "image/png"
                } else if let data = editedImage.jpegData(compressionQuality: 0.8) {
                    imageData = data
                    mimeType = "image/jpeg"
                }
            } else if let originalImage = info[.originalImage] as? UIImage {
                if let data = originalImage.pngData() {
                    imageData = data
                    mimeType = "image/png"
                } else if let data = originalImage.jpegData(compressionQuality: 0.8) {
                    imageData = data
                    mimeType = "image/jpeg"
                }
            }

            if let imageData = imageData, let mimeType = mimeType {
                DispatchQueue.main.async {
                    self.parent.imageData = imageData
                    self.parent.mimeType = mimeType
                }
            }
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }
}
